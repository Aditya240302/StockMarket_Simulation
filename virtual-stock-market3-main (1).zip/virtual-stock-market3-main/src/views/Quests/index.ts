import Quests from './Quests';

export default Quests;